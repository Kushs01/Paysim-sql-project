SELECT type, COUNT(*) AS total_txns, SUM(amount) AS total_amount, ROUND(AVG(amount)::numeric, 2) AS avg_amount
FROM ps
GROUP BY type
ORDER BY total_amount DESC;