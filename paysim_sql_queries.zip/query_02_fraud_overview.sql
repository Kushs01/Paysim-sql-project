SELECT isfraud, COUNT(*) AS total_txns, SUM(amount) AS total_amount, ROUND(AVG(amount)::numeric, 2) AS avg_amount
FROM ps
GROUP BY isfraud
ORDER BY isfraud DESC;