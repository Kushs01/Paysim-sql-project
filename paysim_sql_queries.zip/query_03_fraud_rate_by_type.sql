SELECT type, COUNT(*) AS total_txns,
       SUM(CASE WHEN isfraud = 1 THEN 1 ELSE 0 END) AS fraud_txns,
       ROUND((SUM(CASE WHEN isfraud = 1 THEN 1 ELSE 0 END)::numeric / COUNT(*)::numeric) * 100, 4) AS fraud_rate_percent
FROM ps
GROUP BY type
ORDER BY fraud_rate_percent DESC;